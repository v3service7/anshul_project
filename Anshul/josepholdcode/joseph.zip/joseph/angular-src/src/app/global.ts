
export const url: string = 'http://localhost:3000/';

export const imageUrl: string = '/uploads/';
