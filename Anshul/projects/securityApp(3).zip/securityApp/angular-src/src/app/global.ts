
export const url: string = 'http://52.15.152.174:4002/';

export const imageUrl: string = '/uploads/';
